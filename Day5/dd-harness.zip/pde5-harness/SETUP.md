# 실행 가이드 — Claude Desktop (Code 탭) + Docker 샌드박스

**맥이든 Windows든 동일하게 실행된다.** 자기 OS를 몰라도 된다 —
단일 진입점 `run_harness.py` 가 OS를 자동 감지해 맞는 컨테이너 래퍼를 부른다.

- Bedrock 안 씀 (Claude Desktop 기본 백엔드)
- 모든 계산은 Docker 컨테이너 안에서만 → 호스트(맥/Windows) 오염 없음

---

## 1. 사전 준비 (최초 1회)

### (A) Docker Desktop 설치 — 여기만 OS별로 다르다
- **맥**: https://www.docker.com/products/docker-desktop
  - Apple 메뉴 > 이 Mac에 관하여 에서 칩 확인 → Apple Silicon / Intel 맞는 인스톨러
- **Windows**: 같은 페이지에서 Windows용 → 설치 중 WSL 2 백엔드 활성화(기본값)
- 설치 후 **Docker Desktop을 실행 상태로 둔다** (harness 도는 내내 켜져 있어야 함)

### (B) 파이썬 (런처 실행용, 최소)
- `run_harness.py` 는 표준 라이브러리만 쓰므로 **아무 파이썬 3.x** 면 된다(패키지 설치 불필요).
- 맥은 기본 내장. Windows는 python.org 또는 Microsoft Store에서 파이썬 설치.
- 확인: `python --version` (안 되면 `python3 --version`)

### (C) 이 폴더를 로컬에 배치
- 예) 맥: `~/projects/pde5-harness` / Windows: `C:\Users\<이름>\pde5-harness`

### (D) Claude Desktop 최신 + Code 탭 사용 가능

---

## 2. 샌드박스 점검 (설치 확인)

프로젝트 폴더에서, **OS 관계없이 동일**:
```
python run_harness.py check
```
→ `rdkit ok True` 가 나오면 준비 완료.
(최초엔 컨테이너 이미지를 빌드하느라 수 분 걸린다. 이후엔 캐시 사용)

Docker가 꺼져 있으면 런처가 안내 메시지를 낸다 → Docker Desktop 켜고 재시도.

---

## 3. 실행 (Claude Desktop Code 탭)

Code 탭에서 이 폴더를 열고:
```
SETUP.md, run.md, CLAUDE.md를 읽어줘.
모든 파이썬 실행은 python run_harness.py 를 통해 컨테이너 안에서만 해줘.
호스트에 아무것도 설치하지 말고, PDE5 harness를 Stage 1부터 게이트까지
자율 실행해서 투고 패키지까지 만들어줘.
```

### 수동 실행 예시 (참고 — 모두 OS 공통)
```
python run_harness.py check                        # 샌드박스 점검
python run_harness.py chembl                        # ChEMBL 수집
python run_harness.py loop --max-iter 5             # 생성 닫힌 루프
python run_harness.py skills/mol-generate/scripts/generate.py --seeds outputs/03_strategy/decision.json --ref outputs/02_chembl/actives.csv --n 500 --out outputs/04_candidates/gen1.csv
```

---

## 4. 역할 분담 (중요)

- **컨테이너가 하는 일**: RDKit 생성·필터·채점, ChEMBL 수집 (계산 전부)
- **Claude Desktop 본체가 하는 일**: 웹검색(문헌조사), MCP 호출(Inductive Bio),
  문서 스킬(docx/pptx 보고서·원고 생성)
- Claude는 컨테이너가 남긴 CSV/JSON을 읽어 판단하고 다음 명령을 구성한다.

---

## 5. 팀 협업 (맥·Windows 혼용)

- 같은 폴더(Git 등)를 공유하면 된다. 코드·Dockerfile 동일, 런처가 OS 흡수.
- `.gitignore`에 outputs/ 가 있어 각자 실행 결과가 섞이지 않는다.
- 산출물(CSV/JSON/docx)은 OS 무관 호환.

---

## 6. 문제 해결

| 증상 | 해결 |
|---|---|
| `python: command not found` | `python3 run_harness.py ...` 로 시도, 또는 파이썬 설치 |
| Docker 안내 메시지 | Docker Desktop 실행 확인 |
| 최초 빌드 느림 | RDKit conda 설치(1회). 이후 캐시 |
| 마운트 권한 오류 | Docker Desktop > Settings > Resources > File Sharing 에 폴더 경로 허용 |
| Apple Silicon 특정 패키지 실패 | sandbox/run_in_sandbox.sh 의 docker run 에 `--platform linux/amd64` 추가(느리지만 동작) |

---

## 7. 정리(선택)
- 이미지 삭제: `docker rmi pde5-harness:latest`
- 호스트엔 outputs/ 외 잔여물 없음.
