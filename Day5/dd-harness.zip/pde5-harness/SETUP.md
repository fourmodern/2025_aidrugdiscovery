# 실행 가이드 — Claude Desktop (Code 탭)

**맥이든 Windows든 동일하게 실행된다.** 자기 OS를 몰라도 된다 —
단일 진입점 `run_harness.py` 가 OS를 자동 감지한다.

**두 가지 실행 모드 (자동 선택)**
- **로컬 모드 (Docker 불필요, 기본 폴백)** — Docker가 없으면 프로젝트 안에
  전용 파이썬 환경 `.venv-harness/` 를 자동으로 만들어 거기서 실행한다.
  시스템 파이썬은 건드리지 않는다. **맥·Windows 모두 매끄럽게 동작**.
  필요한 것: 아무 **Python 3.9+** (venv/pip 포함 — python.org/스토어 기본 설치본).
- **Docker 모드 (선택, 격리 강화)** — Docker Desktop이 켜져 있으면 컨테이너에서 실행해
  호스트 오염이 0이 된다. 팀 재현성이 중요할 때 권장.

우선순위: Docker가 켜져 있으면 Docker, 없으면 자동 로컬 모드.
`--no-docker` 로 로컬 강제, `--docker` 로 Docker 강제(없으면 종료).
- Bedrock 안 씀 (Claude Desktop 기본 백엔드)

---

## 1. 사전 준비 (최초 1회)

### (A) 파이썬 3.9+  ← 로컬 모드의 유일한 필수 요건
- `run_harness.py` 자체는 표준 라이브러리만 쓴다. 로컬 모드에서 계산용 패키지는
  런처가 `.venv-harness/` 에 자동 설치하므로 **직접 pip 설치할 필요 없다**.
- 맥은 보통 기본 내장. Windows는 python.org 또는 Microsoft Store에서 설치
  (설치 시 "Add python to PATH" 체크). 확인: `python --version` (안 되면 `python3 --version`).

### (B) Docker Desktop 설치 — **선택** (격리 실행을 원할 때만)
- 없어도 된다. 없으면 자동으로 로컬 모드로 돈다.
- 쓰려면: https://www.docker.com/products/docker-desktop
  - **맥**: Apple 메뉴 > 이 Mac에 관하여 에서 칩 확인 → Apple Silicon / Intel 인스톨러
  - **Windows**: Windows용 → 설치 중 WSL 2 백엔드 활성화(기본값)
  - 설치 후 **Docker Desktop을 실행 상태로 둔다** (Docker 모드로 도는 내내).

### (C) 이 폴더를 로컬에 배치
- 예) 맥: `~/projects/pde5-harness` / Windows: `C:\Users\<이름>\pde5-harness`

### (D) Claude Desktop 최신 + Code 탭 사용 가능

---

## 2. 환경 점검 (설치 확인)

프로젝트 폴더에서, **OS 관계없이 동일**:
```
python run_harness.py check
```
→ `rdkit ok True` 가 나오면 준비 완료.

- **로컬 모드**(Docker 없음): 최초 1회 `.venv-harness/` 생성 + 패키지 설치로 수 분, 이후 캐시.
- **Docker 모드**(Docker 켜짐): 최초 1회 이미지 빌드로 수 분, 이후 캐시.
- Docker를 켜 두면 자동으로 Docker 모드, 아니면 자동 로컬 모드다.
  Docker가 있어도 로컬로 강제하려면: `python run_harness.py check --no-docker`

---

## 3. 실행 (Claude Desktop Code 탭)

Code 탭에서 이 폴더를 열고:
```
SETUP.md, run.md, CLAUDE.md 읽고 harness 자율 실행해줘
```
(원하면 더 구체적으로:)
```
SETUP.md, run.md, CLAUDE.md를 읽어줘.
모든 파이썬 실행은 python run_harness.py 를 통해서만 해줘
(Docker 있으면 컨테이너, 없으면 로컬 모드가 자동 적용됨).
PDE5 harness를 Stage 1부터 게이트까지 자율 실행해서 투고 패키지까지 만들어줘.
```

### 수동 실행 예시 (참고 — 모두 OS 공통)
```
python run_harness.py check                        # 샌드박스 점검
python run_harness.py chembl                        # ChEMBL 수집
python run_harness.py loop --max-iter 5             # 생성 닫힌 루프
python run_harness.py skills/mol-generate/scripts/generate.py --seeds outputs/03_strategy/decision.json --ref outputs/02_chembl/actives.csv --n 500 --out outputs/04_candidates/gen1.csv
```

---

## 4. 역할 분담 (중요)

- **컨테이너가 하는 일**: RDKit 생성·필터·채점, ChEMBL 수집 (계산 전부)
- **Claude Desktop 본체가 하는 일**: 웹검색(문헌조사), MCP 호출(Inductive Bio),
  문서 스킬(docx/pptx 보고서·원고 생성)
- Claude는 컨테이너가 남긴 CSV/JSON을 읽어 판단하고 다음 명령을 구성한다.

---

## 5. 팀 협업 (맥·Windows 혼용)

- 같은 폴더(Git 등)를 공유하면 된다. 코드·Dockerfile 동일, 런처가 OS 흡수.
- `.gitignore`에 outputs/ 가 있어 각자 실행 결과가 섞이지 않는다.
- 산출물(CSV/JSON/docx)은 OS 무관 호환.

---

## 6. 문제 해결

| 증상 | 해결 |
|---|---|
| `python: command not found` | `python3 run_harness.py ...` 로 시도, 또는 파이썬 설치 |
| Docker 안내 메시지 | Docker Desktop 실행 확인 |
| 최초 빌드 느림 | RDKit conda 설치(1회). 이후 캐시 |
| 마운트 권한 오류 | Docker Desktop > Settings > Resources > File Sharing 에 폴더 경로 허용 |
| Apple Silicon 특정 패키지 실패 | sandbox/run_in_sandbox.sh 의 docker run 에 `--platform linux/amd64` 추가(느리지만 동작) |

---

## 7. 정리(선택)
- 이미지 삭제: `docker rmi pde5-harness:latest`
- 호스트엔 outputs/ 외 잔여물 없음.
