#!/usr/bin/env python3
"""
run_harness.py — OS 무관 단일 진입점 (Docker 샌드박스 또는 로컬 모드).

맥/Windows/Linux 어디서든 이거 하나면 된다. 자기 OS를 몰라도 된다 —
런처가 OS를 자동 감지하고, Docker가 있으면 컨테이너에서, 없으면
프로젝트 안의 전용 파이썬 환경(.venv-harness)에서 실행한다.

사용법 (어느 OS든 동일):
    python run_harness.py check
        → 환경(RDKit) 정상 여부 점검  →  'rdkit ok True'
    python run_harness.py <스크립트경로> [인자...]
        → 해당 스크립트 실행
    python run_harness.py loop --max-iter 5     # Stage 4 닫힌 루프 (단축)
    python run_harness.py chembl                 # ChEMBL 수집 (단축)

실행 모드:
    (기본) Docker Desktop이 실행 중이면 컨테이너에서 실행 (호스트 오염 0).
    Docker가 없거나 꺼져 있으면 → 자동으로 '로컬 모드'로 전환한다.
    --no-docker 를 주면 Docker가 있어도 강제로 로컬 모드를 쓴다.
    --docker    를 주면 로컬 폴백 없이 Docker만 쓴다(없으면 종료).

로컬 모드:
    프로젝트 폴더 안에 .venv-harness/ 를 한 번 만들고 rdkit 등을 설치한다.
    최초 1회만 수 분(설치), 이후엔 캐시. 시스템 파이썬은 건드리지 않는다.
    필요한 것: 아무 Python 3.9+ (venv/pip 포함 — python.org/스토어 기본 설치본).
"""
import os
import platform
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
SANDBOX = os.path.join(HERE, "sandbox")
IS_WIN = platform.system().lower() == "windows"

LOCAL_VENV = os.path.join(HERE, ".venv-harness")
# 컨테이너 Dockerfile과 동일한 계산 스택 (로컬 모드에서 pip로 설치)
LOCAL_DEPS = ["rdkit>=2024.3", "pandas", "requests",
              "chembl_webresource_client", "tabulate",
              "python-docx", "python-pptx"]

# 단축 명령 매핑 (값의 선두 'python'은 각 모드에서 알맞은 인터프리터로 대체됨)
SHORTCUTS = {
    "check": ["python", "-c",
              "from rdkit import Chem; "
              "print('rdkit ok', Chem.MolFromSmiles('CCO') is not None)"],
    "chembl": ["python", "skills/chembl-bioactivity/scripts/fetch_chembl.py",
               "--target", "CHEMBL1827",
               "--out", "outputs/02_chembl/actives.csv"],
    "loop": ["python", "skills/mol-generate/scripts/loop.py"],
}


# --------------------------------------------------------------------------- #
# Docker 모드
# --------------------------------------------------------------------------- #
def docker_available():
    """Docker CLI가 있고 데몬이 살아있으면 True."""
    try:
        r = subprocess.run(["docker", "info"],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return r.returncode == 0
    except (FileNotFoundError, OSError):
        return False


def run_docker(inner):
    wrapper = os.path.join(SANDBOX,
                           "run_in_sandbox.bat" if IS_WIN else "run_in_sandbox.sh")
    if not os.path.exists(wrapper):
        print(f"[run_harness] 샌드박스 래퍼를 찾을 수 없습니다: {wrapper}")
        sys.exit(1)
    if not IS_WIN and not os.access(wrapper, os.X_OK):
        os.chmod(wrapper, 0o755)
    full = [wrapper] + inner if IS_WIN else ["bash", wrapper] + inner
    print(f"[run_harness] Docker 모드 → {os.path.basename(wrapper)}")
    print(f"[run_harness] 실행: {' '.join(inner)}")
    return subprocess.run(full, cwd=HERE).returncode


# --------------------------------------------------------------------------- #
# 로컬 모드 (Docker 없이)
# --------------------------------------------------------------------------- #
def venv_python():
    return (os.path.join(LOCAL_VENV, "Scripts", "python.exe") if IS_WIN
            else os.path.join(LOCAL_VENV, "bin", "python"))


def ensure_local_env():
    """프로젝트 전용 venv를 만들고 계산 스택을 설치. 이미 있으면 재사용."""
    py = venv_python()
    if os.path.exists(py):
        return py
    if sys.version_info < (3, 9):
        print("[run_harness] 로컬 모드는 Python 3.9+ 가 필요합니다 "
              f"(현재 {platform.python_version()}). 3.9 이상으로 다시 실행하세요.")
        sys.exit(1)
    print("[run_harness] 로컬 환경(.venv-harness) 생성 중 ... (최초 1회, 수 분)")
    subprocess.run([sys.executable, "-m", "venv", LOCAL_VENV], check=True)
    subprocess.run([py, "-m", "pip", "install", "--quiet", "--upgrade", "pip"],
                   check=True)
    print("[run_harness] 의존성 설치: " + ", ".join(LOCAL_DEPS))
    subprocess.run([py, "-m", "pip", "install", "--quiet", *LOCAL_DEPS], check=True)
    print("[run_harness] 로컬 환경 준비 완료.")
    return py


def run_local(inner):
    py = ensure_local_env()
    if inner and inner[0] in ("python", "python3"):
        inner = inner[1:]
    full = [py] + inner
    print(f"[run_harness] 로컬 모드 실행: {' '.join(inner)}")
    return subprocess.run(full, cwd=HERE).returncode


# --------------------------------------------------------------------------- #
def main():
    args = sys.argv[1:]
    if not args:
        print(__doc__)
        return

    force_local = "--no-docker" in args
    force_docker = "--docker" in args
    args = [a for a in args if a not in ("--no-docker", "--docker")]
    if not args:
        print(__doc__)
        return

    cmd_key, extra = args[0], args[1:]
    inner = SHORTCUTS[cmd_key] + extra if cmd_key in SHORTCUTS else args

    if force_local:
        rc = run_local(inner)
    elif force_docker:
        if not docker_available():
            print("[run_harness] --docker 지정됨이나 Docker를 찾지 못했습니다.")
            print("  → Docker Desktop을 실행하거나, --no-docker(로컬 모드)로 실행하세요. 상세: SETUP.md")
            sys.exit(1)
        rc = run_docker(inner)
    elif docker_available():
        rc = run_docker(inner)
    else:
        print("[run_harness] Docker 미탐지 → 로컬 모드로 자동 전환합니다.")
        print("  (Docker로 격리 실행하려면 Docker Desktop을 켠 뒤 다시 실행. 상세: SETUP.md)")
        rc = run_local(inner)

    sys.exit(rc)


if __name__ == "__main__":
    main()
