#!/usr/bin/env python3
"""
run_harness.py — OS 무관 단일 진입점.

실습생이 자기 OS(맥/Windows/Linux)를 몰라도 이거 하나면 된다.
내부에서 OS를 감지해 맞는 샌드박스 래퍼(.sh/.bat)를 호출한다.

사용법 (어느 OS든 동일):
    python run_harness.py check
        → 샌드박스(RDKit) 정상 여부 점검
    python run_harness.py <스크립트경로> [인자...]
        → 컨테이너 안에서 해당 스크립트 실행
    python run_harness.py loop --max-iter 5
        → Stage 4 닫힌 루프 (단축 명령)
    python run_harness.py chembl
        → ChEMBL 수집 (단축 명령)

Docker Desktop이 실행 중이어야 한다. 호스트에는 아무것도 설치하지 않는다.
"""
import os
import platform
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
SANDBOX = os.path.join(HERE, "sandbox")


def pick_wrapper():
    """호스트 OS에 맞는 래퍼 경로를 반환."""
    system = platform.system().lower()
    if system == "windows":
        return os.path.join(SANDBOX, "run_in_sandbox.bat"), "windows"
    # macOS = 'darwin', Linux = 'linux', WSL도 linux로 잡힘
    return os.path.join(SANDBOX, "run_in_sandbox.sh"), "unix"


def ensure_docker():
    """Docker가 실행 중인지 확인. 아니면 안내하고 종료."""
    try:
        r = subprocess.run(["docker", "info"],
                           stdout=subprocess.DEVNULL,
                           stderr=subprocess.DEVNULL)
        if r.returncode != 0:
            raise RuntimeError
    except (FileNotFoundError, RuntimeError):
        print("[run_harness] Docker가 실행 중이 아닙니다.")
        print("  → Docker Desktop을 설치하고 실행한 뒤 다시 시도하세요.")
        print("    맥: MAC_SETUP.md / Windows: WINDOWS_SETUP.md 참고")
        sys.exit(1)


# 단축 명령 매핑
SHORTCUTS = {
    "check": ["python", "-c",
              "from rdkit import Chem; "
              "print('rdkit ok', Chem.MolFromSmiles('CCO') is not None)"],
    "chembl": ["python", "skills/chembl-bioactivity/scripts/fetch_chembl.py",
               "--target", "CHEMBL1827",
               "--out", "outputs/02_chembl/actives.csv"],
    "loop": ["python", "skills/mol-generate/scripts/loop.py"],
}


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(0)

    ensure_docker()
    wrapper, kind = pick_wrapper()

    if not os.path.exists(wrapper):
        print(f"[run_harness] 래퍼를 찾을 수 없습니다: {wrapper}")
        sys.exit(1)

    # unix 래퍼는 실행권한 필요 — 없으면 부여
    if kind == "unix" and not os.access(wrapper, os.X_OK):
        os.chmod(wrapper, 0o755)

    cmd_key = sys.argv[1]
    extra = sys.argv[2:]

    if cmd_key in SHORTCUTS:
        inner = SHORTCUTS[cmd_key] + extra
    else:
        # 임의 스크립트/명령 그대로 전달
        inner = sys.argv[1:]

    if kind == "windows":
        full = [wrapper] + inner
    else:
        full = ["bash", wrapper] + inner

    print(f"[run_harness] OS={platform.system()} → {os.path.basename(wrapper)}")
    print(f"[run_harness] 실행: {' '.join(inner)}")
    # 프로젝트 루트에서 실행 (래퍼가 상대경로 마운트를 처리)
    r = subprocess.run(full, cwd=HERE)
    sys.exit(r.returncode)


if __name__ == "__main__":
    main()
