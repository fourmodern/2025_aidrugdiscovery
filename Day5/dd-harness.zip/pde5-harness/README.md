# PDE5 저분자 신약개발 자율 Harness

문헌조사 → ChEMBL 데이터 → 브레인스토밍 전략결정 → **PI 리뷰 게이트** → 후보 생성·평가·필터(닫힌 루프) → 보고서 → **악마의 리뷰어 게이트** → 투고 준비까지 자율 완주하는 harness.

fourmodern/2025_aidrugdiscovery 워크숍의 방법론(Day1 ChEMBL/ADME, Day3 ADMET, Day4 분자생성 파이프라인)을 도구·스킬로 구현했다.

## 실행 위치

**Claude Desktop (Code 탭)에서 실행한다.** Bedrock은 쓰지 않는다(기본 Anthropic 백엔드).
모든 계산은 **Docker 컨테이너 샌드박스** 안에서만 돌아 호스트는 오염되지 않는다.

맥·Windows 어느 쪽이든 **동일하게** 실행된다. 자기 OS를 몰라도 된다:
```
python run_harness.py check          # 샌드박스 점검 (OS 자동 감지)
python run_harness.py loop --max-iter 5
```
→ 상세는 **SETUP.md** 참고. 런처가 OS를 감지해 맞는 컨테이너 래퍼를 자동 호출한다.

핵심 역할 분담:
- 계산(RDKit 생성·필터·채점, ChEMBL 수집) → **컨테이너**
- 웹검색·MCP(Inductive Bio)·문서스킬(docx/pptx) → **Claude Desktop 본체**

## 설치 요약

1. Docker Desktop 설치 (WSL 2 백엔드) + 실행 상태 유지
2. 이 폴더를 로컬에 배치, Claude Desktop Code 탭에서 열기
3. 최초 실행 시 컨테이너 자동 빌드 (RDKit conda 설치, 1회 수 분)
4. 호스트에 파이썬/RDKit 설치 불필요

## 구조

```
pde5-harness/
├── CLAUDE.md        제어 정책 (harness engineering 4원칙, 게이트 규칙, 샌드박스 실행 규칙)
├── run.md           실행 진입점 (Stage 1~7 + Gate 1,2)
├── SETUP.md         맥·Windows 공통 셋업 (Docker 샌드박스)
├── run_harness.py   ★ 단일 진입점 런처 (OS 자동 감지)
├── sandbox/         격리 실행 환경
│   ├── Dockerfile              RDKit conda 이미지
│   ├── run_in_sandbox.bat      Windows 실행 래퍼
│   └── run_in_sandbox.sh       macOS/Linux/WSL 래퍼
├── agents/          8개 에이전트 (5 실행 + 2 게이트 + 1 투고)
│   ├── literature-searcher.md   Stage 1
│   ├── data-curator.md          Stage 2
│   ├── strategist.md            Stage 3 (브레인스토밍)
│   ├── pi-reviewer.md           ◆ Gate 1 (전략 심사)
│   ├── mol-designer.md          Stage 4 (생성 루프)
│   ├── report-writer.md         Stage 5 (보고서)
│   ├── devils-reviewer.md       ◆ Gate 2 (적대적 심사)
│   └── submission-prep.md       Stage 7 (투고)
├── skills/          실행 스킬 (동작 검증된 스크립트 포함)
│   ├── chembl-bioactivity/      ChEMBL 수집·정제 (fetch_chembl.py)
│   ├── brainstorm-strategy/     전략 결정 → decision.json
│   ├── mol-generate/            생성·필터 (generate.py) + 루프 (loop.py)
│   └── admet-score/             ADMET 채점 (score.py, Inductive Bio 병합)
└── outputs/         산출물 (실행 시 생성) + run_log.jsonl (관측성)
```

## Harness Engineering 관점

이 harness는 모델을 바꾸지 않고 스캐폴딩으로 자율성을 만든다:

- **도구 레이어**: ChEMBL·RDKit·Inductive Bio를 스킬로 노출
- **생성/검증 분리**: 각 단계가 generator, 게이트/스코어러가 validator
- **닫힌 루프**: Stage 4 생성-채점 반복 + 게이트 반려-재작업 루프
- **관측성**: 모든 단계가 run_log.jsonl에 이벤트 기록, 보고서에 실행 이력 편입
- **게이트**: PI 리뷰·악마의 리뷰어가 품질 관문. 재시도 상한으로 무한루프 방지

## 중요 한계

생성된 후보 분자는 **in silico 가설**이다. 합성·assay 실험 검증 전까지 결론이 아니다.
악마의 리뷰어 게이트가 이 정직성을 강제한다(음성 결과 은폐·과잉 해석 차단).

## Inductive Bio MCP 연동 (Stage 4 validator 강화)

loop.py는 RDKit 지표만으로도 자율 완주한다. Inductive Bio를 더하려면 오케스트레이터가 각 iteration에서:
1. `generated_iter{N}.csv`의 통과 후보 SMILES를 Inductive Bio predict 도구로 채점
2. 결과를 `outputs/04_candidates/ib_iter{N}.json` 로 `{smiles: {prop: value}}` 형식 저장
3. loop.py가 자동 감지해 composite_score에 ADMET 항(가중치 0.20)을 병합

## 커스터마이즈

- 타겟 변경: CLAUDE.md의 타겟 ID + chembl-bioactivity `--target` 인자
- 생성 백엔드 교체: mol-generate/scripts/generate.py의 `generate_backend()`를
  REINVENT4/MolGen/VAE(워크숍 Day4)로 교체 (GPU 필요)
- 게이트 엄격도: pi-reviewer/devils-reviewer의 임계 점수·재시도 상한 조정
