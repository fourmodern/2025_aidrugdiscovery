@echo off
REM ============================================================
REM  run_in_sandbox.bat — 컨테이너 안에서 harness 명령을 실행
REM  호스트 Windows에는 파이썬/RDKit이 없어도 된다.
REM
REM  사용법 (Claude Code가 이 형태로 호출):
REM    run_in_sandbox.bat python skills\mol-generate\scripts\loop.py --max-iter 5
REM
REM  프로젝트 폴더 전체가 컨테이너의 /work 에 마운트되므로
REM  outputs\ 산출물은 그대로 호스트에 남는다.
REM ============================================================

setlocal

REM 이 배치파일이 있는 sandbox\ 의 부모 = 프로젝트 루트
set "PROJECT_ROOT=%~dp0.."
pushd "%PROJECT_ROOT%"
set "PROJECT_ROOT=%CD%"
popd

set "IMAGE=pde5-harness:latest"

REM 이미지가 없으면 자동 빌드
docker image inspect %IMAGE% >nul 2>&1
if errorlevel 1 (
    echo [sandbox] 이미지가 없어 빌드합니다. 최초 1회 수 분 소요...
    docker build -t %IMAGE% "%PROJECT_ROOT%\sandbox"
    if errorlevel 1 (
        echo [sandbox] 빌드 실패. Docker Desktop이 실행 중인지 확인하세요.
        exit /b 1
    )
)

REM 프로젝트 루트를 /work 에 마운트하고, 전달된 명령을 컨테이너 안에서 실행
REM Windows 경로의 백슬래시는 컨테이너 안에서 문제되지 않도록 스크립트가 os.path 사용
docker run --rm ^
    -v "%PROJECT_ROOT%:/work" ^
    -w /work ^
    %IMAGE% ^
    %*

endlocal
