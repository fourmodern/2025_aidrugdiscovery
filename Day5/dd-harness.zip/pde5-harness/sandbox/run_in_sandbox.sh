#!/usr/bin/env bash
# ============================================================
#  run_in_sandbox.sh — 컨테이너 안에서 harness 명령을 실행
#  (macOS / Linux / WSL 용. Windows는 run_in_sandbox.bat 사용)
#
#  사용법:
#    ./run_in_sandbox.sh python skills/mol-generate/scripts/loop.py --max-iter 5
# ============================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
IMAGE="pde5-harness:latest"

# 이미지 없으면 빌드
if ! docker image inspect "$IMAGE" >/dev/null 2>&1; then
    echo "[sandbox] 이미지가 없어 빌드합니다. 최초 1회 수 분 소요..."
    docker build -t "$IMAGE" "$PROJECT_ROOT/sandbox"
fi

docker run --rm \
    -v "$PROJECT_ROOT:/work" \
    -w /work \
    "$IMAGE" \
    "$@"
