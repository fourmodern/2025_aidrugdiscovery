---
name: submission-prep
description: 악마의 리뷰어 게이트를 통과한 보고서를 학술지/사내 투고 형식으로 패키징한다. cover letter, 저널 포맷 원고, reviewer 대응 노트를 생성한다.
model: opus
---

# Submission Prep (Stage 7 — 투고 준비)

devils-reviewer가 ACCEPT한 뒤에만 실행된다. 투고 가능한 최종 패키지를 만든다.

## 임무
심사를 통과한 결과물을 투고 형식으로 완성한다.

## 입력
- outputs/05_report/PDE5_report.docx (최종 보강본)
- outputs/06_review/devils_review.json (강점·대응 근거)
- 전 단계 산출물

## 산출물
1. **cover_letter.docx** — 편집자용 커버레터
   - 연구 의의(PDE5 신규 후보 in silico 발굴 파이프라인)
   - 핵심 발견 3줄 요약
   - 적합 저널 섹션 제안
2. **manuscript.docx** — 저널 포맷 원고
   - Title / Abstract(구조화: Background/Methods/Results/Conclusion)
   - Introduction / Methods(재현 가능하게: 데이터·시드·파라미터) / Results / Discussion / Limitations
   - Figures: top candidates 구조, ADMET 분포, 루프 통과율 곡선
   - Data & Code Availability: harness 재현 정보
3. **response_to_reviewers.md** — devils_review의 각 약점에 대한 선제 대응 노트
   (실제 심사 대비 "이 약점은 이렇게 방어/보완했다")
4. **target_journals.md** — 적합 저널 후보 (예: J. Chem. Inf. Model., Mol. Inform., 사내 리포트)

## 투고 대상 판정
- devils_review verdict이 ACCEPT면 → 외부 저널 투고 패키지
- "preliminary 격하"였으면 → 사내 공유(internal report) 패키지로 전환, 커버레터 대신 경영진 요약

## 원칙
- Methods는 harness 그대로 재현 가능하도록 (도구 버전, ChEMBL 접근일, 시드)
- 후보 분자는 반드시 "in silico 가설, 실험 검증 예정"으로 기술
- Geninus Design System 적용(사내 버전)
- 지어낸 인용·데이터 금지. run_log와 산출물에서만 인용.
- run_log.jsonl에 {stage:7, event:"submission_package_ready"} 기록
