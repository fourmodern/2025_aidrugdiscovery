# run.md — PDE5 Harness 실행 진입점

이 파일은 오케스트레이터(main Claude Code 세션)가 읽는 시작 지시서다.
`CLAUDE.md`의 제어 정책을 먼저 로드한 뒤, 아래 순서로 실행한다.

## 실행 절차

```
0. 준비
   - 모든 파이썬 실행은 `python run_harness.py ...` 경유 (OS 자동 감지).
   - 실행 모드: Docker Desktop이 켜져 있으면 컨테이너, 없으면 자동 로컬 모드
     (.venv-harness). 시스템 파이썬은 건드리지 않는다. 상세 SETUP.md.
   - outputs/ 디렉토리 생성, run_log.jsonl 초기화
   - SEED=42 고정
   - 환경 점검: python run_harness.py check   (rdkit ok True 확인)

1. Stage 1 — 문헌조사
   → agents/literature-searcher.md 를 dispatch
   → 산출: outputs/01_literature/summary.md, refs.json

2. Stage 2 — ChEMBL 실험데이터
   → agents/data-curator.md 를 dispatch
   → skills/chembl-bioactivity 사용
   → 산출: outputs/02_chembl/actives.csv

3. Stage 3 — 브레인스토밍 전략결정
   → agents/strategist.md 를 dispatch
   → skills/brainstorm-strategy 사용
   → 산출: outputs/03_strategy/decision.json + rationale.md

3.5 Gate 1 — PI 리뷰  ◆
   → agents/pi-reviewer.md 를 dispatch
   → decision.json 심사 → pi_review.json
   → verdict == PASS 면 Stage 4 진행
   → verdict == REVISE 면 required_changes 반영해 Stage 3 재실행 (최대 2회)
   → 2회 후에도 REVISE면 최선 버전으로 조건부 통과, 기록 남기고 진행

4. Stage 4 — 후보 생성·평가·필터 [닫힌 루프]
   → agents/mol-designer.md 를 dispatch
   → skills/mol-generate/scripts/loop.py 실행 (generate→filter→score 반복)
   → Inductive Bio MCP 연결 시: 각 iter의 통과 후보 SMILES를 predict 도구로 채점,
     ib_iter{N}.json 저장 → loop가 자동 병합
   → 산출: outputs/04_candidates/ranked_candidates.csv

5. Stage 5 — 보고서
   → agents/report-writer.md 를 dispatch
   → docx + pptx 스킬, Geninus Design System, run_log 요약 포함
   → 산출: outputs/05_report/PDE5_report.docx, PDE5_deck.pptx

5.5 Gate 2 — 악마의 리뷰어  ◆
   → agents/devils-reviewer.md 를 dispatch
   → 보고서 적대적 심사 → devils_review.json
   → verdict == ACCEPT 면 Stage 7 진행
   → MAJOR_REVISION 이면 required_revisions 반영해 Stage 5 보강 (최대 2회)
   → critical 결함이면 우선 수정, 근본 결함이면 "preliminary"로 격하해 사내 공유 전환

6. Stage 7 — 투고 준비
   → agents/submission-prep.md 를 dispatch
   → cover letter + manuscript + response_to_reviewers + target_journals
   → 산출: outputs/07_submission/

7. 완료
   → outputs/07_submission/ 과 05_report/ 의 파일 경로를 사용자에게 제시
   → run_log.jsonl 기반 전체 실행 이력 요약 출력
```

## 게이트 재작업 규칙
- 게이트가 REVISE/MAJOR_REVISION을 반환하면, 반려된 단계만 재실행하고 다시 게이트로 돌아온다.
- 재시도 카운터를 run_log.jsonl로 추적. 상한 도달 시 무한루프 방지 위해 조건부 통과.

## 중단·재개
- 각 Stage 완료 시 outputs/에 산출물이 남으므로, 중단 후 재실행하면 이미 완료된 Stage는 건너뛴다(산출물 존재 여부로 판단).

## 시작 명령 예시 (맥/Windows 공통, Claude Desktop Code 탭)
```
SETUP.md, run.md, CLAUDE.md를 읽어줘.
모든 파이썬 실행은 python run_harness.py 를 통해서만 해줘
(Docker 있으면 컨테이너, 없으면 로컬 모드가 자동 적용됨).
PDE5 harness를 Stage 1부터 게이트까지 자율 실행해서 투고 패키지까지 만들어줘.
```
