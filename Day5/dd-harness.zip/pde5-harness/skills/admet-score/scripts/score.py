#!/usr/bin/env python3
"""
Score candidates with druglikeness + optional Inductive Bio ADMET predictions.
Based on fourmodern/2025_aidrugdiscovery Day3 ADMET methodology.
Produces composite_score in [0,1].
"""
import argparse, json, os
from datetime import datetime, timezone


def log_event(logpath, **kw):
    kw["ts"] = datetime.now(timezone.utc).isoformat()
    os.makedirs(os.path.dirname(logpath), exist_ok=True)
    with open(logpath, "a") as f:
        f.write(json.dumps(kw, ensure_ascii=False) + "\n")


def veber_pass(mol):
    from rdkit.Chem import rdMolDescriptors, Descriptors
    rotb = rdMolDescriptors.CalcNumRotatableBonds(mol)
    tpsa = rdMolDescriptors.CalcTPSA(mol)
    return rotb <= 10 and tpsa <= 140


def lipinski_pass(mol):
    from rdkit.Chem import Descriptors, Crippen, rdMolDescriptors
    mw = Descriptors.MolWt(mol)
    logp = Crippen.MolLogP(mol)
    hbd = rdMolDescriptors.CalcNumHBD(mol)
    hba = rdMolDescriptors.CalcNumHBA(mol)
    viol = sum([mw > 500, logp > 5, hbd > 5, hba > 10])
    return viol <= 1


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="inp", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--inductive-bio-results", default=None,
                    help="optional JSON {smiles: {prop: value}} from Inductive Bio MCP")
    ap.add_argument("--composite-min", type=float, default=0.6)
    ap.add_argument("--log", default="outputs/run_log.jsonl")
    args = ap.parse_args()

    import pandas as pd
    from rdkit import Chem

    df = pd.read_csv(args.inp)
    # only score filter-passing candidates if that column exists
    if "passed_filter" in df.columns:
        df = df[df["passed_filter"]].copy()

    ib = {}
    if args.inductive_bio_results and os.path.exists(args.inductive_bio_results):
        with open(args.inductive_bio_results) as f:
            ib = json.load(f)

    has_ib = len(ib) > 0
    rows = []
    for _, r in df.iterrows():
        smi = r["smiles"]
        m = Chem.MolFromSmiles(smi)
        if m is None:
            continue
        qed = float(r.get("qed", 0.0))
        sa = float(r.get("sa_score", 5.0))
        qed_norm = qed
        sa_norm = (sa - 1) / 9.0
        lip = lipinski_pass(m)
        veb = veber_pass(m)
        druglike = 0.5 * lip + 0.5 * veb

        rec = dict(r)
        # merge Inductive Bio predictions
        admet_ext = None
        if has_ib and smi in ib:
            props = ib[smi]
            for k, v in props.items():
                rec[f"admet_{k}"] = v
            # normalize numeric props to [0,1] naively (assume already probability-like);
            # if not, orchestrator should pre-normalize. Take mean of numeric in [0,1].
            vals = [float(v) for v in props.values()
                    if isinstance(v, (int, float)) and 0 <= float(v) <= 1]
            if vals:
                admet_ext = sum(vals) / len(vals)

        if has_ib and admet_ext is not None:
            composite = (0.35 * qed_norm + 0.25 * (1 - sa_norm)
                         + 0.20 * admet_ext + 0.20 * druglike)
        else:
            # renormalize without ADMET term: weights sum to 0.8 -> scale to 1.0
            composite = (0.35 * qed_norm + 0.25 * (1 - sa_norm) + 0.20 * druglike) / 0.80

        rec["lipinski_pass"] = lip
        rec["veber_pass"] = veb
        rec["composite_score"] = round(float(composite), 4)
        rec["pass"] = bool(composite >= args.composite_min)
        rows.append(rec)

    out = pd.DataFrame(rows).sort_values("composite_score", ascending=False)
    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    out.to_csv(args.out, index=False)

    log_event(args.log, stage=4, event="scored", n=len(out),
              n_pass=int(out["pass"].sum()) if len(out) else 0,
              used_inductive_bio=has_ib, out=args.out)
    print(f"[admet-score] scored={len(out)} pass={int(out['pass'].sum()) if len(out) else 0} "
          f"(inductive_bio={'yes' if has_ib else 'no'}) -> {args.out}")


if __name__ == "__main__":
    main()
