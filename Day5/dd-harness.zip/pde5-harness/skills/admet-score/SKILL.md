---
name: admet-score
description: 후보 분자의 ADMET 특성과 약물유사성을 예측·채점해 composite score를 산출한다. Inductive Bio MCP(있으면)와 RDKit 계산 지표를 결합한다. 후보 분자 평가·랭킹 요청 시 반드시 이 스킬을 사용한다.
---

# ADMET Scoring Skill

fourmodern/2025_aidrugdiscovery Day3(ADMET 예측, hERG 심장독성)의 방법론을 스킬로 구현.
validator 레이어 — Stage 4 닫힌 루프에서 후보를 객관 지표로 채점한다.

## 언제 사용하나
- mol-generate가 필터를 통과시킨 후보들을 ADMET로 채점·랭킹할 때
- composite_score를 만들어 success_criteria 임계와 비교할 때

## 채점 소스 (우선순위)
1. **Inductive Bio MCP** (연결돼 있으면): 분자 물성 예측 모델 호출
   - 오케스트레이터가 MCP 도구를 tool_search로 로드 → 각 SMILES에 대해 predict 호출
   - 반환된 예측치(용해도, 투과성, 독성 등)를 admet_* 컬럼으로 병합
2. **RDKit 계산 지표** (항상): QED, SA, TPSA, Lipinski, Veber(회전결합/TPSA), PAINS
   - Inductive Bio가 없거나 실패해도 이 지표만으로 채점 가능(harness 자율성 보장)

## composite_score 정의 (0~1, 높을수록 좋음)
```
composite = 0.35*QED_norm + 0.25*(1 - SA_norm) + 0.20*ADMET_ext + 0.20*druglike_rules
```
- QED_norm = QED (이미 0~1)
- SA_norm = (SA - 1) / 9  (1~10 → 0~1, 낮을수록 합성 쉬움)
- ADMET_ext = Inductive Bio 예측 정규화 평균 (없으면 이 항 제외하고 나머지 가중치 재정규화)
- druglike_rules = (Lipinski 통과? 0.5) + (Veber 통과? 0.5)

## 사용법
```bash
python scripts/score.py \
  --in outputs/04_candidates/generated_iter1.csv \
  --out outputs/04_candidates/scored_iter1.csv \
  --inductive-bio-results outputs/04_candidates/ib_iter1.json   # 선택
```

- `--inductive-bio-results`: 오케스트레이터가 MCP로 받은 예측을 JSON으로 저장해 넘기면 병합.
  없으면 RDKit 지표만으로 composite 산출(가중치 자동 재정규화).

## Inductive Bio MCP 연동 (오케스트레이터가 수행)
1. tool_search로 Inductive Bio predict 도구 로드
2. 통과 후보 SMILES 리스트를 predict에 전달
3. 결과를 {smiles: {prop: value}} 형태 JSON으로 저장
4. score.py에 --inductive-bio-results로 전달

## 출력 계약
scored_*.csv (원본 컬럼 + admet_* + composite_score + pass). run_log.jsonl 기록.
