---
name: brainstorm-strategy
description: 문헌조사와 ChEMBL 데이터를 종합해 분자 설계 전략을 구조화된 브레인스토밍으로 결정하고 decision.json 계약을 생성한다. "어떻게 할지 결정" 단계에서 반드시 이 스킬을 사용한다.
---

# Brainstorm Strategy Skill

harness의 핵심 판단 단계(Stage 3). 사람의 "어떻게 할지 브레인스토밍"을 구조화된 절차로 대체한다.

## 언제 사용하나
- 문헌(Stage1)과 데이터(Stage2)를 받아 설계 전략을 확정할 때
- 이후 생성 단계가 소비할 decision.json을 만들 때

## 브레인스토밍 절차 (구조화된 자기질문 → 근거 기반 결정)

오케스트레이터/strategist agent가 아래 질문에 데이터로 답한다:

### Q1. Scaffold 선정
- ChEMBL summary.md의 Murcko scaffold Top5 확인
- 문헌 summary.md의 "신규 scaffold 2024/2025" 언급 대조
- 결정: 빈도(활성 근거)와 신규성(특허 회피)의 균형으로 1~3개 seed 선정
- PDE5 맥락: pyrazolopyrimidinone(sildenafil), β-carboline(tadalafil) 계열이 대표. 신규성 위해 변형 우선.

### Q2. 최적화 목표 우선순위
- 문헌의 "선택성 이슈(PDE6)" "저항성/미충족" 인사이트 반영
- 후보: potency / selectivity_vs_PDE6 / oral_admet / half_life
- 결정: 문헌이 지적한 최대 약점을 1순위로

### Q3. 생성 제약 (데이터 기반)
- actives.csv에서 MW/logP의 5~95 percentile을 그대로 constraints로
- qed_min: active 중앙값 근처(보통 0.5), sa_max: 4.5

### Q4. 성공 기준
- n_candidates: 목표 통과 후보 수 (기본 20)
- composite_score_min: 0.6

## 출력 계약 (CLAUDE.md 스키마 준수)
- outputs/03_strategy/decision.json
- outputs/03_strategy/rationale.md — 각 Q의 답과 근거(문헌·데이터 인용)

## 원칙
- 모든 값은 실행 가능해야 한다(다음 단계가 그대로 소비)
- 추측이 아니라 산출물에서 인용해 정한다
- rationale.md에 "왜 이 scaffold/목표/제약인가"를 반드시 서술
