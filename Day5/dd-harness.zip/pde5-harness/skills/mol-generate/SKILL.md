---
name: mol-generate
description: seed scaffold를 기반으로 신규 후보 분자(SMILES)를 생성하고 validity/uniqueness/novelty를 평가하며 QED·SA·PAINS로 필터링한다. 분자 생성·유사체 설계 요청 시 반드시 이 스킬을 사용한다.
---

# Molecule Generation Skill

fourmodern/2025_aidrugdiscovery Day4(분자생성 파이프라인: 생성→평가(validity/uniqueness/novelty)→필터(QED/SA))의 방법론을 스킬로 구현.

## 언제 사용하나
- decision.json의 seed_scaffold에서 유사체를 생성할 때
- 생성물을 validity/uniqueness/novelty로 평가하고 QED/SA/PAINS로 거를 때

## 설계 철학
프로덕션에서는 REINVENT4/MolGen/VAE(Day4)를 GPU로 돌리지만, 이 스킬은 **CPU에서도 자율 실행되는 결정론적 생성기**를 기본 제공한다(harness가 GPU 없이도 완주하도록). GPU 생성 모델이 있으면 `--backend` 로 교체 가능.

## 사용법
```bash
# 샌드박스 경유 실행 (컨테이너에 rdkit/pandas 포함)
# 단건 생성:
sandbox/run_in_sandbox.sh python skills/mol-generate/scripts/generate.py --seeds outputs/03_strategy/decision.json --ref outputs/02_chembl/actives.csv --n 500 --out outputs/04_candidates/generated_iter1.csv --seed 42
# 전체 닫힌 루프 (권장):
sandbox/run_in_sandbox.sh python skills/mol-generate/scripts/loop.py --max-iter 5 --per-iter 500
# Windows는 run_in_sandbox.bat 사용
```

## 생성 방식 (기본 backend: mutate)
- seed scaffold + ChEMBL active에서 추출한 프래그먼트/치환기 라이브러리를 조합
- RDKit 기반 결정론적 변이: R-group 치환, 링 치환기 추가, bioisostere 교체
- 모든 생성물 RDKit sanitize 통과 필수

## 평가 지표 (Day4 방식)
- **validity**: RDKit로 파싱·sanitize 성공 비율
- **uniqueness**: 생성 집합 내 canonical SMILES 중복 제거 비율
- **novelty**: ref(ChEMBL actives) 대비 신규 비율 (Tanimoto<0.4 or 미포함)

## 필터 (decision.json constraints 적용)
- MW/logP 범위, QED>=qed_min, SA score<=sa_max
- PAINS 서브구조 제거 (Day1 T003 방식, RDKit FilterCatalog)

## 출력 계약
generated_iter{N}.csv (smiles, qed, sa_score, mw, logp, novel, passed_filter). run_log.jsonl 기록.
