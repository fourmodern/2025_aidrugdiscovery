#!/usr/bin/env python3
"""
Stage 4 closed-loop driver: generate -> filter -> score -> accumulate -> iterate.
Stops when success_criteria met or MAX_ITER reached.

Note on Inductive Bio MCP:
  This driver runs the RDKit-only path autonomously. To fold in Inductive Bio ADMET
  predictions, the ORCHESTRATOR (Claude Code, which has MCP access) should, each
  iteration, take generated_iter{N}.csv passing rows, call the Inductive Bio predict
  tool, write ib_iter{N}.json, and pass it to score.py via --inductive-bio-results.
  The driver auto-detects ib_iter{N}.json if present.
"""
import argparse, json, os, subprocess, sys
from datetime import datetime, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
GEN = os.path.join(HERE, "generate.py")
SCORE = os.path.join(os.path.dirname(HERE), "..", "admet-score", "scripts", "score.py")


def log_event(logpath, **kw):
    kw["ts"] = datetime.now(timezone.utc).isoformat()
    os.makedirs(os.path.dirname(logpath), exist_ok=True)
    with open(logpath, "a") as f:
        f.write(json.dumps(kw, ensure_ascii=False) + "\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--decision", default="outputs/03_strategy/decision.json")
    ap.add_argument("--ref", default="outputs/02_chembl/actives.csv")
    ap.add_argument("--outdir", default="outputs/04_candidates")
    ap.add_argument("--max-iter", type=int, default=5)
    ap.add_argument("--per-iter", type=int, default=500)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--log", default="outputs/run_log.jsonl")
    args = ap.parse_args()

    import pandas as pd

    os.makedirs(args.outdir, exist_ok=True)
    with open(args.decision) as f:
        decision = json.load(f)
    target_n = decision["success_criteria"]["n_candidates"]
    comp_min = decision["success_criteria"].get("composite_score_min", 0.6)

    accumulated = []
    seeds_path = args.decision

    for it in range(1, args.max_iter + 1):
        gen_out = os.path.join(args.outdir, f"generated_iter{it}.csv")
        subprocess.run([sys.executable, GEN, "--seeds", seeds_path, "--ref", args.ref,
                        "--n", str(args.per_iter), "--out", gen_out,
                        "--seed", str(args.seed + it), "--log", args.log], check=True)

        ib_path = os.path.join(args.outdir, f"ib_iter{it}.json")
        scored_out = os.path.join(args.outdir, f"scored_iter{it}.csv")
        score_cmd = [sys.executable, SCORE, "--in", gen_out, "--out", scored_out,
                     "--composite-min", str(comp_min), "--log", args.log]
        if os.path.exists(ib_path):
            score_cmd += ["--inductive-bio-results", ib_path]
        subprocess.run(score_cmd, check=True)

        if os.path.exists(scored_out):
            sdf = pd.read_csv(scored_out)
            passed = sdf[sdf["pass"]] if "pass" in sdf.columns else sdf.head(0)
            passed = passed.copy()
            passed["iter_found"] = it
            accumulated.append(passed)
            total = sum(len(a) for a in accumulated)
            log_event(args.log, stage=4, event="iteration", iter=it,
                      n_passed_this=len(passed), n_accumulated=total)
            if total >= target_n:
                log_event(args.log, stage=4, event="target_met", iter=it, total=total)
                break

    if accumulated:
        allc = pd.concat(accumulated, ignore_index=True)
        allc = allc.drop_duplicates(subset=["smiles"]).sort_values(
            "composite_score", ascending=False)
    else:
        import pandas as pd
        allc = pd.DataFrame()

    ranked = os.path.join(args.outdir, "ranked_candidates.csv")
    allc.to_csv(ranked, index=False)

    status = "success" if len(allc) >= target_n else "partial"
    # summary
    with open(os.path.join(args.outdir, "summary.md"), "w") as f:
        f.write("# Stage 4 — 후보 생성 루프 요약\n\n")
        f.write(f"- 상태: **{status}** (목표 {target_n}, 확보 {len(allc)})\n")
        f.write(f"- composite_score 임계: {comp_min}\n\n")
        f.write("## Top 10 후보\n\n")
        cols = [c for c in ["smiles", "qed", "sa_score", "mw", "logp",
                            "composite_score", "iter_found"] if c in allc.columns]
        if len(allc):
            f.write(allc[cols].head(10).to_markdown(index=False))
        f.write("\n\n> 후보 분자는 실험(합성·assay) 검증 전 **가설**입니다.\n")

    log_event(args.log, stage=4, event="done", status=status, n_final=len(allc))
    print(f"[loop] status={status} n_final={len(allc)} -> {ranked}")


if __name__ == "__main__":
    main()
