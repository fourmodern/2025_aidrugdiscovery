#!/usr/bin/env python3
"""
Generate candidate molecules from seed scaffolds, evaluate validity/uniqueness/novelty,
filter by QED/SA/PAINS/constraints.
Based on fourmodern/2025_aidrugdiscovery Day4 pipeline.

Default backend 'mutate' is CPU-friendly and deterministic so the harness completes
without GPU. Swap in REINVENT4/MolGen/VAE by implementing generate_backend().
"""
import argparse, json, os, random
from datetime import datetime, timezone


def log_event(logpath, **kw):
    kw["ts"] = datetime.now(timezone.utc).isoformat()
    os.makedirs(os.path.dirname(logpath), exist_ok=True)
    with open(logpath, "a") as f:
        f.write(json.dumps(kw, ensure_ascii=False) + "\n")


# ---- SA score (Ertl & Schuffenhauer) via RDKit contrib if available, else heuristic ----
def get_sa_scorer():
    try:
        from rdkit.Chem import RDConfig
        import sys, os as _os
        sys.path.append(_os.path.join(RDConfig.RDContribDir, "SA_Score"))
        import sascorer
        return sascorer.calculateScore
    except Exception:
        # fallback heuristic: penalize size & ring complexity (rougher but functional)
        from rdkit.Chem import Descriptors, rdMolDescriptors
        def heur(mol):
            nrings = rdMolDescriptors.CalcNumRings(mol)
            nheavy = mol.GetNumHeavyAtoms()
            return min(10.0, 1.0 + 0.02 * nheavy + 0.5 * nrings)
        return heur


def build_fragment_library(ref_csv):
    """Extract common R-groups / substituents from ChEMBL actives for recombination."""
    import pandas as pd
    from rdkit import Chem
    from rdkit.Chem import BRICS
    frags = set()
    if ref_csv and os.path.exists(ref_csv):
        df = pd.read_csv(ref_csv)
        for smi in df["smiles"].dropna().head(500):
            m = Chem.MolFromSmiles(smi)
            if m is None:
                continue
            for f in BRICS.BRICSDecompose(m):
                frags.add(f)
    # minimal fallback library
    if not frags:
        frags = {"[*]F", "[*]Cl", "[*]C", "[*]OC", "[*]N", "[*]C(=O)N", "[*]c1ccccc1"}
    return list(frags)


def generate_backend(seeds, frag_lib, n, rng):
    """Deterministic candidate generation via two complementary strategies:
    (1) BRICS recombination of seed + library fragments
    (2) deterministic R-group decoration on aromatic H positions of seeds
    Both paths sanitize; only valid unique SMILES are returned.
    """
    from rdkit import Chem
    from rdkit.Chem import BRICS, AllChem
    from rdkit import RDLogger
    RDLogger.DisableLog("rdApp.*")

    out, seen = [], set()

    def add(m):
        try:
            Chem.SanitizeMol(m)
            smi = Chem.MolToSmiles(m)
            if smi and smi not in seen and Chem.MolFromSmiles(smi) is not None:
                seen.add(smi)
                out.append(smi)
                return True
        except Exception:
            return False
        return False

    # ---- Strategy 1: BRICS recombination ----
    seed_frags = set()
    for s in seeds:
        m = Chem.MolFromSmiles(s)
        if m:
            for f in BRICS.BRICSDecompose(m):
                seed_frags.add(f)
    pool = list(seed_frags) + list(frag_lib)
    frag_mols = [Chem.MolFromSmiles(f) for f in pool if Chem.MolFromSmiles(f)]
    frag_mols = [m for m in frag_mols if m is not None]
    if frag_mols:
        try:
            builder = BRICS.BRICSBuild(frag_mols)  # no seed kwarg in this RDKit
            for i, m in enumerate(builder):
                if i > n * 8 or len(out) >= n:
                    break
                add(m)
        except Exception:
            pass

    # ---- Strategy 2: deterministic R-group decoration ----
    # Substituents commonly seen in kinase/PDE chemistry
    subs = ["F", "Cl", "C", "OC", "N", "C#N", "C(F)(F)F", "S(C)(=O)=O",
            "N1CCOCC1", "N1CCN(C)CC1", "c1ccccc1", "O"]
    for s in seeds:
        base = Chem.MolFromSmiles(s)
        if base is None:
            continue
        # find aromatic carbons with an implicit H to decorate
        positions = [a.GetIdx() for a in base.GetAtoms()
                     if a.GetIsAromatic() and a.GetTotalNumHs() > 0
                     and a.GetSymbol() == "C"]
        for pos in positions:
            for sub in subs:
                if len(out) >= n:
                    break
                rw = Chem.RWMol(Chem.MolFromSmiles(s))
                frag = Chem.MolFromSmiles(sub)
                if frag is None:
                    continue
                combo = Chem.CombineMols(rw, frag)
                ed = Chem.RWMol(combo)
                # attach first atom of frag to the aromatic position
                frag_start = rw.GetNumAtoms()
                try:
                    ed.AddBond(pos, frag_start, Chem.BondType.SINGLE)
                    m2 = ed.GetMol()
                    add(m2)
                except Exception:
                    continue
    return out[:n]


def novelty_flags(smiles_list, ref_csv):
    from rdkit import Chem
    from rdkit.Chem import AllChem, DataStructs
    ref_fps = []
    if ref_csv and os.path.exists(ref_csv):
        import pandas as pd
        df = pd.read_csv(ref_csv)
        for smi in df["smiles"].dropna():
            m = Chem.MolFromSmiles(smi)
            if m:
                ref_fps.append(AllChem.GetMorganFingerprintAsBitVect(m, 2, 2048))
    flags = []
    for smi in smiles_list:
        m = Chem.MolFromSmiles(smi)
        if m is None:
            flags.append(False); continue
        fp = AllChem.GetMorganFingerprintAsBitVect(m, 2, 2048)
        max_sim = 0.0
        for rfp in ref_fps:
            s = DataStructs.TanimotoSimilarity(fp, rfp)
            if s > max_sim:
                max_sim = s
            if max_sim >= 0.4:
                break
        flags.append(max_sim < 0.4)
    return flags


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", required=True, help="decision.json path")
    ap.add_argument("--ref", default="outputs/02_chembl/actives.csv")
    ap.add_argument("--n", type=int, default=500)
    ap.add_argument("--out", required=True)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--log", default="outputs/run_log.jsonl")
    args = ap.parse_args()

    import pandas as pd
    from rdkit import Chem
    from rdkit.Chem import Descriptors, Crippen, QED, rdMolDescriptors
    from rdkit.Chem import FilterCatalog

    random.seed(args.seed)
    rng = random.Random(args.seed)

    with open(args.seeds) as f:
        decision = json.load(f)
    seeds = decision["seed_scaffold_smiles"]
    con = decision["generation_constraints"]

    frag_lib = build_fragment_library(args.ref)
    raw = generate_backend(seeds, frag_lib, args.n, rng)
    log_event(args.log, stage=4, event="generated_raw", n=len(raw))

    # validity/uniqueness already handled (sanitized + dedup in backend)
    novel = novelty_flags(raw, args.ref)
    sa_score = get_sa_scorer()

    # PAINS catalog
    params = FilterCatalog.FilterCatalogParams()
    params.AddCatalog(FilterCatalog.FilterCatalogParams.FilterCatalogs.PAINS)
    catalog = FilterCatalog.FilterCatalog(params)

    rows = []
    for smi, nov in zip(raw, novel):
        m = Chem.MolFromSmiles(smi)
        if m is None:
            continue
        mw = Descriptors.MolWt(m)
        logp = Crippen.MolLogP(m)
        try:
            qed = QED.qed(m)
        except Exception:
            qed = 0.0
        sa = float(sa_score(m))
        pains = catalog.HasMatch(m)
        passed = (con["mw"][0] <= mw <= con["mw"][1]
                  and con["logp"][0] <= logp <= con["logp"][1]
                  and qed >= con.get("qed_min", 0.5)
                  and sa <= con.get("sa_max", 4.5)
                  and not pains)
        rows.append({"smiles": smi, "qed": round(qed, 3), "sa_score": round(sa, 2),
                     "mw": round(mw, 1), "logp": round(logp, 2),
                     "novel": nov, "pains": pains, "passed_filter": bool(passed)})

    df = pd.DataFrame(rows)
    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    df.to_csv(args.out, index=False)

    n_valid = len(df)
    n_pass = int(df["passed_filter"].sum()) if len(df) else 0
    log_event(args.log, stage=4, event="filtered", n_valid=n_valid,
              n_passed=n_pass, out=args.out)
    print(f"[mol-generate] valid={n_valid} passed_filter={n_pass} -> {args.out}")


if __name__ == "__main__":
    main()
