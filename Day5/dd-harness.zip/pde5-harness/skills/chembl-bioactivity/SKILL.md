---
name: chembl-bioactivity
description: ChEMBL 데이터베이스에서 특정 타겟의 활성 화합물과 생물활성(IC50/Ki/pchembl)을 조회하고, RDKit로 정제·표준화·물성계산까지 수행한다. PDE5 등 신약 타겟의 실험 데이터 수집 요청 시 반드시 이 스킬을 사용한다.
---

# ChEMBL Bioactivity Skill

fourmodern/2025_aidrugdiscovery Day1 T001(ChEMBL 데이터 조회)·T002(ADME 필터링)의 방법론을 재사용 가능한 스킬로 구현한 것.

## 언제 사용하나
- ChEMBL에서 타겟별 활성 화합물을 수집할 때
- 수집 데이터를 RDKit로 정제하고 약물유사 물성(MW/logP/QED/RO5)을 계산할 때

## 사용법
```bash
# 샌드박스 경유 실행 (호스트에 설치하지 않음). 패키지는 컨테이너에 포함됨.
# Windows:
sandbox\run_in_sandbox.bat python skills/chembl-bioactivity/scripts/fetch_chembl.py --target CHEMBL1827 --out outputs/02_chembl/actives.csv --pchembl-min 6.0
# macOS/Linux/WSL:
sandbox/run_in_sandbox.sh python skills/chembl-bioactivity/scripts/fetch_chembl.py --target CHEMBL1827 --out outputs/02_chembl/actives.csv --pchembl-min 6.0
```

- `--target`: ChEMBL 타겟 ID (PDE5A = CHEMBL1827)
- `--pchembl-min`: active 라벨 임계 (기본 6.0 = IC50 1uM). 데이터 부족 시 스크립트가 5.5로 자동 완화
- 출력: actives.csv (chembl_id, smiles, pchembl_value, standard_type, mw, logp, hbd, hba, tpsa, qed, ro5_violations)

## 정제 파이프라인 (스크립트 내장)
1. IC50/Ki 중 pchembl_value 존재 레코드만
2. Salt stripping (RDKit SaltRemover) + 최대 프래그먼트 선택
3. Canonical SMILES 표준화, 중복 제거
4. RDKit 물성: MolWt, MolLogP, NumHDonors, NumHAcceptors, TPSA, QED
5. Lipinski RO5 위반 수 계산

## 출력 계약
actives.csv + summary.md(pchembl 분포, Murcko scaffold top5). run_log.jsonl에 {stage:2, n_compounds} 기록.

## 실패 대안
chembl_webresource_client 실패 시 → ChEMBL REST API 직접 호출
(https://www.ebi.ac.uk/chembl/api/data/activity?target_chembl_id=CHEMBL1827&format=json)
