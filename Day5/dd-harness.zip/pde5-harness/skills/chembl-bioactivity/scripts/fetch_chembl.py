#!/usr/bin/env python3
"""
Fetch and curate ChEMBL bioactivity data for a target.
Based on fourmodern/2025_aidrugdiscovery Day1 T001/T002 methodology.
"""
import argparse, json, os, sys, time
from datetime import datetime, timezone


def log_event(logpath, **kw):
    kw["ts"] = datetime.now(timezone.utc).isoformat()
    os.makedirs(os.path.dirname(logpath), exist_ok=True)
    with open(logpath, "a") as f:
        f.write(json.dumps(kw, ensure_ascii=False) + "\n")


def fetch_via_client(target, pchembl_min):
    from chembl_webresource_client.new_client import new_client
    act = new_client.activity
    res = act.filter(target_chembl_id=target,
                     standard_type__in=["IC50", "Ki"],
                     pchembl_value__isnull=False).only(
        ["molecule_chembl_id", "canonical_smiles", "pchembl_value", "standard_type"])
    rows = []
    for r in res:
        if r.get("canonical_smiles") and r.get("pchembl_value"):
            rows.append({
                "chembl_id": r["molecule_chembl_id"],
                "smiles": r["canonical_smiles"],
                "pchembl_value": float(r["pchembl_value"]),
                "standard_type": r["standard_type"],
            })
    return rows


def fetch_via_rest(target, pchembl_min):
    import requests
    base = "https://www.ebi.ac.uk/chembl/api/data/activity"
    rows, offset, limit = [], 0, 1000
    while True:
        url = (f"{base}?target_chembl_id={target}&format=json"
               f"&limit={limit}&offset={offset}")
        for attempt in range(3):
            try:
                resp = requests.get(url, timeout=60)
                resp.raise_for_status()
                break
            except Exception:
                time.sleep(2 ** attempt)
        else:
            break
        data = resp.json()
        activities = data.get("activities", [])
        if not activities:
            break
        for r in activities:
            st = r.get("standard_type")
            pc = r.get("pchembl_value")
            sm = r.get("canonical_smiles")
            if st in ("IC50", "Ki") and pc and sm:
                rows.append({
                    "chembl_id": r.get("molecule_chembl_id"),
                    "smiles": sm,
                    "pchembl_value": float(pc),
                    "standard_type": st,
                })
        if len(activities) < limit:
            break
        offset += limit
    return rows


def curate(rows, pchembl_min, logpath):
    import pandas as pd
    from rdkit import Chem
    from rdkit.Chem import Descriptors, Crippen, QED, rdMolDescriptors
    from rdkit.Chem.SaltRemover import SaltRemover
    from rdkit.Chem.Scaffolds import MurckoScaffold

    remover = SaltRemover()
    seen, out = set(), []
    for r in rows:
        mol = Chem.MolFromSmiles(r["smiles"])
        if mol is None:
            continue
        mol = remover.StripMol(mol)
        frags = Chem.GetMolFrags(mol, asMols=True)
        if frags:
            mol = max(frags, key=lambda m: m.GetNumAtoms())
        can = Chem.MolToSmiles(mol)
        if can in seen:
            continue
        seen.add(can)
        mw = Descriptors.MolWt(mol)
        logp = Crippen.MolLogP(mol)
        hbd = rdMolDescriptors.CalcNumHBD(mol)
        hba = rdMolDescriptors.CalcNumHBA(mol)
        tpsa = rdMolDescriptors.CalcTPSA(mol)
        try:
            qed = QED.qed(mol)
        except Exception:
            qed = None
        ro5 = sum([mw > 500, logp > 5, hbd > 5, hba > 10])
        out.append({**r, "smiles": can, "mw": round(mw, 2), "logp": round(logp, 2),
                    "hbd": hbd, "hba": hba, "tpsa": round(tpsa, 2),
                    "qed": round(qed, 3) if qed is not None else None,
                    "ro5_violations": ro5})
    df = pd.DataFrame(out)
    if len(df):
        df["active"] = df["pchembl_value"] >= pchembl_min
        if df["active"].sum() < 100 and pchembl_min > 5.5:
            df["active"] = df["pchembl_value"] >= 5.5
            log_event(logpath, stage=2, event="threshold_relaxed", new_min=5.5)
    return df


def murcko_top(df, n=5):
    from rdkit import Chem
    from rdkit.Chem.Scaffolds import MurckoScaffold
    from collections import Counter
    c = Counter()
    for s in df["smiles"]:
        m = Chem.MolFromSmiles(s)
        if m:
            scaf = MurckoScaffold.MurckoScaffoldSmiles(mol=m)
            if scaf:
                c[scaf] += 1
    return c.most_common(n)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--target", default="CHEMBL1827")
    ap.add_argument("--out", default="outputs/02_chembl/actives.csv")
    ap.add_argument("--pchembl-min", type=float, default=6.0)
    ap.add_argument("--log", default="outputs/run_log.jsonl")
    args = ap.parse_args()

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    log_event(args.log, stage=2, event="start", target=args.target)

    rows = []
    try:
        rows = fetch_via_client(args.target, args.pchembl_min)
        log_event(args.log, stage=2, event="fetched_client", n=len(rows))
    except Exception as e:
        log_event(args.log, stage=2, event="client_failed", error=str(e)[:200])
        rows = fetch_via_rest(args.target, args.pchembl_min)
        log_event(args.log, stage=2, event="fetched_rest", n=len(rows))

    if not rows:
        log_event(args.log, stage=2, event="no_data")
        sys.exit("No data fetched from ChEMBL")

    df = curate(rows, args.pchembl_min, args.log)
    df.to_csv(args.out, index=False)

    # summary
    scafs = murcko_top(df[df["active"]] if "active" in df else df)
    sm_path = os.path.join(os.path.dirname(args.out), "summary.md")
    with open(sm_path, "w") as f:
        f.write(f"# ChEMBL {args.target} — Bioactivity Summary\n\n")
        f.write(f"- 총 화합물(정제 후): {len(df)}\n")
        if "active" in df:
            f.write(f"- Active (pchembl>=임계): {int(df['active'].sum())}\n")
        f.write(f"- pchembl 범위: {df['pchembl_value'].min():.2f} ~ {df['pchembl_value'].max():.2f}\n")
        f.write(f"- MW 5~95 percentile: {df['mw'].quantile(0.05):.0f} ~ {df['mw'].quantile(0.95):.0f}\n")
        f.write(f"- logP 5~95 percentile: {df['logp'].quantile(0.05):.2f} ~ {df['logp'].quantile(0.95):.2f}\n\n")
        f.write("## Murcko Scaffold Top 5\n")
        for s, cnt in scafs:
            f.write(f"- `{s}` : {cnt}\n")

    log_event(args.log, stage=2, event="done", n_compounds=len(df),
              n_active=int(df["active"].sum()) if "active" in df else None)
    print(f"[chembl-bioactivity] wrote {len(df)} compounds -> {args.out}")


if __name__ == "__main__":
    main()
