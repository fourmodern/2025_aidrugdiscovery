# CLAUDE.md — PDE5 저분자 신약개발 자율 Harness

> **실행 모드**: autopilot (완전 자율, 사용자에게 질문 금지)
> **타겟**: PDE5 (Phosphodiesterase 5A, UniProt O76074, ChEMBL: CHEMBL1827)
> **목표**: 문헌조사 → ChEMBL 실험데이터 → 브레인스토밍 전략결정 → 후보 생성·평가·필터(닫힌 루프) → 보고서(docx+pptx)까지 자율 완주
> **근거 자료**: fourmodern/2025_aidrugdiscovery 워크숍의 방법론을 도구·스킬로 구현

---

## 0. Harness 설계 원칙 (harness engineering)

이 harness는 **모델을 바꾸지 않고 주변 스캐폴딩으로 자율 완주**를 달성한다. 네 가지 축:

1. **도구 레이어 (Tools)**: ChEMBL·PubMed·RDKit·Inductive Bio MCP를 스킬로 노출
2. **생성/검증 분리 (Generator/Validator)**: 각 단계에서 생성물을 객관 지표로 채점
3. **닫힌 루프 (Closed Loop)**: 임계값 미달 시 재생성. 최대 반복 횟수로 무한루프 방지
4. **관측성 (Observability)**: 모든 단계가 `outputs/`에 산출물 + `run_log.jsonl`에 이벤트 기록

## 1. 절대 규칙

- **질문 금지**: 어떤 상황에서도 사용자에게 되묻지 않는다. 모호하면 문헌·데이터 근거로 자율 판단.
- **샌드박스 경유 실행 (필수)**: 모든 파이썬/계산 실행은 **단일 진입점 런처를 통해서만** 한다. 호스트에 파이썬 패키지를 설치하지 않는다.
  - **어느 OS든 동일**: `python run_harness.py <스크립트> <인자>`
    - 런처가 OS(맥/Windows/Linux)와 실행 환경을 자동 감지한다: Docker가 켜져 있으면 컨테이너 래퍼(.sh/.bat), 없으면 프로젝트 전용 로컬 환경(.venv-harness)을 만들어 실행한다. Claude도 실습생도 OS/Docker 유무를 신경 쓸 필요 없다.
  - 단축 명령: `python run_harness.py check`(환경 점검), `python run_harness.py chembl`(ChEMBL 수집), `python run_harness.py loop --max-iter 5`(생성 루프)
  - 직접 `python skills/...`을 호스트 시스템 파이썬으로 부르거나 시스템에 `pip install`하는 것은 금지. 모든 실행은 run_harness.py를 거친다. 필요한 패키지는 실행 환경(컨테이너 이미지 또는 .venv-harness)에 자동 포함된다.
  - 단, run_harness.py 자체는 호스트 파이썬으로 실행한다(표준 라이브러리만 사용하므로 설치 불필요). 이것이 유일한 예외다.
  - 역할 분담: **계산(RDKit·ChEMBL)은 격리 실행 환경(컨테이너 또는 .venv-harness)**, **웹검색·MCP·문서스킬(docx/pptx)은 Claude 본체**가 수행한다.
- **스킬 우선**: 각 단계는 반드시 해당 스킬을 사용한다. SKILL.md를 먼저 읽고 실행.
- **실패 시 대안**: API 실패 → 재시도(3회, 지수 백오프) → 대안 경로(REST 직접호출/캐시). 그래도 실패하면 로그에 기록하고 부분 결과로 진행.
- **결정론 확보**: 랜덤 시드 고정(SEED=42). 재현 가능해야 함.
- **가설임을 명시**: 생성된 후보 분자는 **실험 검증 전 가설**이다. 보고서에 반드시 이 한계를 적는다.

## 2. 실행 파이프라인 (게이트 포함)

게이트(◆)는 통과해야 다음 단계로 진행하는 관문이다. 반려 시 이전 단계를 재작업한다.

```
Stage 1  문헌조사 (literature-review 스킬)
   │  PubMed/Europe PMC → PDE5 생물학·승인약물·저항성·미충족수요
   ↓  outputs/01_literature/
Stage 2  실험데이터 (chembl-bioactivity 스킬)
   │  ChEMBL CHEMBL1827 → 활성 화합물·pIC50·물성 → 정제·표준화
   ↓  outputs/02_chembl/
Stage 3  브레인스토밍 결정 (brainstorm-strategy 스킬)
   │  1+2 종합 → scaffold·목표·제약·성공기준 확정
   ↓  outputs/03_strategy/decision.json
◆ Gate 1  PI 리뷰 (pi-reviewer agent)
   │  전략 심사. PASS → Stage 4 / REVISE → Stage 3 재작업(최대 2회)
   ↓  outputs/03_strategy/pi_review.json
Stage 4  후보 생성·평가·필터 [닫힌 루프] (mol-generate + admet-score 스킬)
   │  generate → validity/uniqueness/novelty → QED·SA·PAINS 필터
   │  → ADMET 채점(Inductive Bio MCP + RDKit) → 미달분 재생성
   │  목표 N개 확보 or MAX_ITER(=5)까지
   ↓  outputs/04_candidates/ranked_candidates.csv
Stage 5  보고서 (docx + pptx 스킬)
   │  전 단계 종합 → 기술보고서 + 발표덱, Geninus Design System
   ↓  outputs/05_report/
◆ Gate 2  악마의 리뷰어 (devils-reviewer agent)
   │  적대적 심사(Reviewer 2). ACCEPT → Stage 7
   │  MAJOR_REVISION → Stage 5 보강(최대 2회) / critical → 우선 수정
   ↓  outputs/06_review/devils_review.json
Stage 7  투고 준비 (submission-prep agent)
   │  cover letter + 저널 포맷 원고 + reviewer 대응 노트 + 대상저널
   ↓  outputs/07_submission/
```

### 게이트 공통 원칙
- 게이트는 **구조화된 판정(JSON) + 실행 가능한 반려 사유**를 남긴다
- 재시도 상한(2회) 도달 시 harness가 멈추지 않도록: 최선 버전 채택 + 미해결 약점을 "Limitations"에 정직하게 편입하고 진행
- 게이트 통과/반려는 모두 run_log.jsonl에 기록 (관측성)

## 3. 단계 간 계약 (Contracts)

각 단계는 다음 단계가 소비할 **표준 산출물**을 남긴다. 형식이 맞아야 다음 단계가 실행된다.

- Stage1 → `outputs/01_literature/summary.md`, `refs.json`
- Stage2 → `outputs/02_chembl/actives.csv` (컬럼: chembl_id, smiles, pchembl_value, standard_type)
- Stage3 → `outputs/03_strategy/decision.json` (아래 스키마)
- Gate1 → `outputs/03_strategy/pi_review.json` (verdict: PASS/REVISE)
- Stage4 → `outputs/04_candidates/ranked_candidates.csv` (컬럼: smiles, qed, sa_score, admet_*, composite_score, pass)
- Stage5 → `outputs/05_report/PDE5_report.docx`, `PDE5_deck.pptx`
- Gate2 → `outputs/06_review/devils_review.json` (verdict: ACCEPT/MAJOR_REVISION/REJECT)
- Stage7 → `outputs/07_submission/manuscript.docx`, `cover_letter.docx`, `response_to_reviewers.md`, `target_journals.md`

### decision.json 스키마 (Stage 3의 출력 = Stage 4의 입력 계약)
```json
{
  "target": "PDE5",
  "seed_scaffold_smiles": ["<선정된 대표 scaffold SMILES>"],
  "optimization_objectives": ["potency", "selectivity_vs_PDE6", "oral_admet"],
  "generation_constraints": {"mw": [250, 500], "logp": [1, 4], "qed_min": 0.5, "sa_max": 4.5},
  "success_criteria": {"n_candidates": 20, "composite_score_min": 0.6},
  "rationale": "<문헌+ChEMBL 근거 요약>"
}
```

## 4. 관측성 (필수)

모든 스킬은 실행 시 `outputs/run_log.jsonl`에 한 줄씩 append:
```json
{"ts": "...", "stage": 4, "event": "iteration", "iter": 2, "n_generated": 500, "n_passed": 14, "note": "..."}
```
Stage 5 보고서에는 이 로그를 요약한 "실행 이력" 섹션을 포함한다.

## 5. 디렉토리 구조

```
pde5-harness/
├── CLAUDE.md                 ← 이 파일 (제어 정책)
├── run.md                    ← 시작 지시 (오케스트레이터가 읽는 진입점)
├── agents/                   ← 서브에이전트 정의
│   ├── literature-searcher.md
│   ├── data-curator.md
│   ├── strategist.md
│   ├── pi-reviewer.md        ← Gate 1
│   ├── mol-designer.md
│   ├── report-writer.md
│   ├── devils-reviewer.md    ← Gate 2
│   └── submission-prep.md
├── skills/                   ← 단계별 실행 스킬
│   ├── chembl-bioactivity/
│   ├── mol-generate/
│   ├── admet-score/
│   └── brainstorm-strategy/
└── outputs/                  ← 모든 산출물 (실행 시 생성)
```

## 6. 시작

오케스트레이터는 `run.md`를 읽고 Stage 1부터 순서대로 실행한다. 각 Stage는 해당 agent를 dispatch하고, agent는 skills/의 SKILL.md를 읽어 실행한다.
